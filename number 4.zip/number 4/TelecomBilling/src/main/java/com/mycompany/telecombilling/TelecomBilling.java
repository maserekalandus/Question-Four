/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.telecombilling;

/**
 *
 * @author HP
 */
public class TelecomBilling {

    public static void main(String[] args) {
        double initialAirtime = 10000.0; 
        double airtimeChargeRate = 0.10; 
        double callChargePerSecond = 200.0; 

        int callDurationInMinutes = 5;
        int callDurationInSeconds = callDurationInMinutes * 60; 

        double airtimeCharge = initialAirtime * airtimeChargeRate;
        double callCharge = callDurationInSeconds * callChargePerSecond;
        double balance = initialAirtime - airtimeCharge - callCharge;

        System.out.printf("Initial Airtime Loaded: UGX%.2f%n", initialAirtime);
        System.out.printf("Airtime Charge (10%%): UGX%.2f%n", airtimeCharge);
        System.out.printf("Call Charge for %d seconds: UGX%.2f%n", callDurationInSeconds, callCharge);
        System.out.printf("Remaining Balance: UGX%.2f%n", balance);
    }
}

